package com.example.floatmath_withlint;

public interface Exerciser {
    public void exercise();
}
