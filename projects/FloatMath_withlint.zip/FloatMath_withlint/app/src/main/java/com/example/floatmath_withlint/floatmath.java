package com.example.floatmath_withlint;

import android.util.FloatMath;

//This project is used for FloatMath lint without lint.

public class floatmath implements Exerciser {

    @Override
    public void exercise() {
        double a = FloatMath.sqrt(9);
    }
}
