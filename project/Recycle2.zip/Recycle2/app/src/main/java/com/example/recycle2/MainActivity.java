package com.example.recycle2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.prepareForNextRun();
    }


    private void prepareForNextRun() {
        try {
            for (int i = 0; i < 5; i++) {
                System.gc();
                Thread.sleep(200);
            }
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

