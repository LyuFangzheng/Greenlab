package com.example.recycle2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.time.Instant;

//The first part have lint while the second not, comment one of them when generate apk.


//public class Recycle {
//    static Mysql mysql;
//    static SQLiteDatabase db;
//    static ContentValues values;
//
//    public void Findpath(Context context, String bookname) {
//        long startTimeStamp;
//        long endTimestamp;
//
//        Instant currentInstant = Instant.now();
//        startTimeStamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();
//
//        NewSQL(context);
//
//        for(int i=0; i<10000000; i++) {
//            Cursor cursor = db.rawQuery("select path from shuju where name=?", new String[]{bookname});
//            cursor.moveToNext();
//            String path = cursor.getString(cursor.getColumnIndex("path"));
//
//        }
//        currentInstant = Instant.now();
//        endTimestamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();
//
//
//        Log.i("START", "START: " + Long.toString(startTimeStamp));
//        Log.i("END", "END: " + Long.toString(endTimestamp));
//        Log.i("DIFFERENCE", "DIFFERENCE: " + Long.toString(endTimestamp - startTimeStamp));
//
//    }
//
//    private static void NewSQL(Context context) {
//        mysql = new Mysql(context);
//        db = mysql.getReadableDatabase();
//        values = new ContentValues();
//    }
//}
//
public class Recycle {
    static Mysql mysql;
    static SQLiteDatabase db;
    static ContentValues values;

    public void Findpath(Context context, String bookname) {
        long startTimeStamp;
        long endTimestamp;

        Instant currentInstant = Instant.now();
        startTimeStamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();

        NewSQL(context);

        for(int i=0; i<10000000; i++) {
            int offset = 10;
            Cursor cursor = db.rawQuery("select path from shuju where name=?", new String[]{bookname});
            cursor.moveToNext();
            String path = cursor.getString(cursor.getColumnIndex("path"));
            cursor.close();

        }
        currentInstant = Instant.now();
        endTimestamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();


        Log.i("START", "START: " + Long.toString(startTimeStamp));
        Log.i("END", "END: " + Long.toString(endTimestamp));
        Log.i("DIFFERENCE", "DIFFERENCE: " + Long.toString(endTimestamp - startTimeStamp));

    }

    private static void NewSQL(Context context) {
        mysql = new Mysql(context);
        db = mysql.getReadableDatabase();
        values = new ContentValues();
    }
}