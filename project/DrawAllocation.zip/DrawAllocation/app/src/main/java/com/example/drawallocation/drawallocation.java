package com.example.drawallocation;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import java.time.Instant;

//The first part have lint while the second not, comment one of them when generate apk.

//public class drawallocation extends View {
//    private int offset = 10;
//
//    public drawallocation(Context context, AttributeSet attrs) {
//
//        super(context, attrs);
//    }
//
//    public void setOffset(int offset) {
//        this.offset = offset;
//    }
//
//    @Override
//    public void onDraw(Canvas canvas) {
//        long startTimeStamp;
//        long endTimestamp;
//
//        Instant currentInstant = Instant.now();
//        startTimeStamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();
//
//        for(int i=0; i<10000000; i++) {
//        int offset = 10;
//        Paint paint = new Paint();
//        super.onDraw(canvas);
//        paint.setColor(Color.RED);
//        paint.setStrokeWidth(10);
//        canvas.drawLine(10, 10 + offset, 10, 10, paint);
//    }
//        currentInstant = Instant.now();
//        endTimestamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();
//
//
//        Log.i("START", "START: " + Long.toString(startTimeStamp));
//        Log.i("END", "END: " + Long.toString(endTimestamp));
//        Log.i("DIFFERENCE", "DIFFERENCE: " + Long.toString(endTimestamp - startTimeStamp));
//  }
//}

public class drawallocation extends View {

    Paint paint;

    public drawallocation(Context context) {
        super(context);
    }


    @Override
    public void onDraw(Canvas canvas) {
        long startTimeStamp;
        long endTimestamp;

        Instant currentInstant = Instant.now();
        startTimeStamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();

        for(int i=0; i<10000000; i++) {
            int offset = 10;
            super.onDraw(canvas);
            paint.setColor(Color.RED);
            paint.setStrokeWidth(10);
            canvas.drawLine(10, 10 + offset, 10, 10, paint);
        }

        currentInstant = Instant.now();
        endTimestamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();


        Log.i("START", "START: " + Long.toString(startTimeStamp));
        Log.i("END", "END: " + Long.toString(endTimestamp));
        Log.i("DIFFERENCE", "DIFFERENCE: " + Long.toString(endTimestamp - startTimeStamp));
    }
}