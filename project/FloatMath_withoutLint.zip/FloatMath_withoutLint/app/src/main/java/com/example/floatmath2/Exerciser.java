package com.example.floatmath2;

public interface Exerciser {
    public void exercise();
}
