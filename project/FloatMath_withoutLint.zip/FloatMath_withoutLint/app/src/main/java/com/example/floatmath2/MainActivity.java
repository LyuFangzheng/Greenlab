package com.example.floatmath2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Debug;
import android.os.SystemClock;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.FloatMath;
import android.util.Log;

import java.time.Instant;

public class MainActivity extends AppCompatActivity {

    final int rounds = 10000000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.prepareForNextRun();

        this.startExerciser();
    }

    private void startExerciser() {
        // Just the following line of code must be changed so that it refers to another class (one class for each type of performance issue).
        Exerciser exerciser = new floatmath();

        long startTimeStamp;
        long endTimestamp;

        Instant currentInstant = Instant.now();
        startTimeStamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();

        for(int i=0; i<this.rounds; i++) {
            exerciser.exercise();
        }

        currentInstant = Instant.now();
        endTimestamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();

        Log.i("START", "START: " + Long.toString(startTimeStamp));
        Log.i("END", "END: " + Long.toString(endTimestamp));
        Log.i("DIFFERENCE", "DIFFERENCE: " + Long.toString(endTimestamp - startTimeStamp));
    }

    private void prepareForNextRun() {
        try {
            for (int i = 0; i < 5; i++) {
                System.gc();
                Thread.sleep(200);
            }
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
