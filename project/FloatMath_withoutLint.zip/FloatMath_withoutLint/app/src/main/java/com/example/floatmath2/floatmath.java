package com.example.floatmath2;
import java.lang.Math;
import android.util.FloatMath;

//This project is used for FloatMath lint without lint.

public class floatmath implements Exerciser {

    @Override
    public void exercise() {
        double a = Math.sqrt(9);
    }
}
