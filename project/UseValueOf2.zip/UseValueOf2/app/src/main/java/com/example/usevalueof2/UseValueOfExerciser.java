package com.example.usevalueof2;

import android.util.Log;

//The first part have lint while the second not, comment one of them when generate apk.

//public class UseValueOfExerciser implements Exerciser {
//
//    @Override
//    public void exercise() {
//        Double d = new Double(Math.random());
//    }
//}

public class UseValueOfExerciser implements Exerciser {

    @Override
    public void exercise() {
            Double d = Double.valueOf(Math.random());
    }
}