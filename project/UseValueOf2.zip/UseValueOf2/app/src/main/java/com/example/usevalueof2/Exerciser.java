package com.example.usevalueof2;

public interface Exerciser {
    public void exercise();
}