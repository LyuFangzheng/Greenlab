package com.example.handlerleak3;

import android.os.Handler;
import android.os.Message;

public class handlerleak  extends Handler {

//The first part have lint while the second not, comment one of them when generate apk.

//    Handler mHandler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            Double d = Double.valueOf(Math.random());
//        }
//    };

    Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            Double d = Double.valueOf(Math.random());
            return false;
        }
    });


}
