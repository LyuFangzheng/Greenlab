package com.example.viewholder4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    final int rounds = 10000000;

    private ListView lv;

    private BaseAdapter listViewAdapter;

    private List<String> listViewData = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < 50; i++) {
            listViewData.add("text" + i);
        }

        lv = (ListView) findViewById(R.id.lv);

        listViewAdapter = new ListViewAdapter(listViewData, this);
        lv.setAdapter(listViewAdapter);

        this.prepareForNextRun();

    }

    private void prepareForNextRun() {
        try {
            for (int i = 0; i < 5; i++) {
                System.gc();
                Thread.sleep(200);
            }
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
