package com.example.viewholder4;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.time.Instant;
import java.util.List;

//The first part have lint while the second not, comment one of them when generate apk.


//public class ListViewAdapter extends BaseAdapter {
//
//    private List<String> listViewData;
//
//    private Context mContext;
//
//    public ListViewAdapter(List<String> listViewData, Context mContext) {
//        this.listViewData = listViewData;
//        this.mContext = mContext;
//    }
//
//    @Override
//    public int getCount() {
//        return listViewData.size();
//    }
//
//    @Override
//    public Object getItem(int i) {
//        return listViewData.get(i);
//    }
//
//    @Override
//    public long getItemId(int i) {
//        return i;
//    }
//
//    @Override
//    public View getView(int i, View view, ViewGroup viewGroup) {
//
//        long startTimeStamp;
//        long endTimestamp;
//        View item = View.inflate(mContext, R.layout.item, null);;
//
//        Instant currentInstant = Instant.now();
//        startTimeStamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();
//
//
//        currentInstant = Instant.now();
//        endTimestamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();
//
//
//        Log.i("START", "START: " + Long.toString(startTimeStamp));
//        Log.i("END", "END: " + Long.toString(endTimestamp));
//        Log.i("DIFFERENCE", "DIFFERENCE: " + Long.toString(endTimestamp - startTimeStamp));
//
//        ViewHolder vh = null;
//        vh = new ViewHolder();
//        //找到文本框
//        vh.tv = (TextView) item.findViewById(R.id.tv);
//        //找到复选框
//        vh.cb = (CheckBox) item.findViewById(R.id.cb);
//        //让item和ViewHolder绑定在一起
//        item.setTag(vh);
//
//        vh.tv.setText(listViewData.get(i));
//
//        //还原状态
//        vh.cb.setChecked(false);
//
//        return item;
//    }
//        class ViewHolder {
//        TextView tv;
//        CheckBox cb;
//    }
//
//}




public class ListViewAdapter extends BaseAdapter {

    private List<String> listViewData;

    private Context mContext;

    public ListViewAdapter(List<String> listViewData, Context mContext) {
        this.listViewData = listViewData;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return listViewData.size();
    }

    @Override
    public Object getItem(int i) {
        return listViewData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        long startTimeStamp;
        long endTimestamp;

        //Item对应的试图
        View item = null;

        Instant currentInstant = Instant.now();
        startTimeStamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();


        currentInstant = Instant.now();
        endTimestamp = currentInstant.plusNanos(currentInstant.getNano()).toEpochMilli();


        Log.i("START", "START: " + Long.toString(startTimeStamp));
        Log.i("END", "END: " + Long.toString(endTimestamp));
        Log.i("DIFFERENCE", "DIFFERENCE: " + Long.toString(endTimestamp - startTimeStamp));

        ViewHolder vh = null;

        if (view == null) {
            item = View.inflate(mContext, R.layout.item, null);
            vh = new ViewHolder();
            //找到文本框
            vh.tv = (TextView) item.findViewById(R.id.tv);
            //找到复选框
            vh.cb = (CheckBox) item.findViewById(R.id.cb);
            //让item和ViewHolder绑定在一起
            item.setTag(vh);
        } else {
            //复用ListView给的View
            item = view;
            //拿出ViewHolder
            vh = (ViewHolder) item.getTag();
        }

        //设置文本内容
        vh.tv.setText(listViewData.get(position));

        //还原状态
        vh.cb.setChecked(false);

        return item;
    }

    /**
     * 用于存放一个ItemView中的控件,由于这里只有两个控件,那么声明两个控件即可
     */
    class ViewHolder {
        TextView tv;
        CheckBox cb;
    }

}
