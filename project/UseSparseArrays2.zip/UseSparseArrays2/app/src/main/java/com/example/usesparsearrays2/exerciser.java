package com.example.usesparsearrays2;

public interface exerciser {
    public void exercise();
}
