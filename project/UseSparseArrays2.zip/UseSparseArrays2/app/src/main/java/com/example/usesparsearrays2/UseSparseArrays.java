package com.example.usesparsearrays2;

import android.util.SparseArray;

import java.util.HashMap;

//The first part have lint while the second not, comment one of them when generate apk.


public class UseSparseArrays implements exerciser{
    @Override
    public void exercise() {
        HashMap<Integer, String> map = new HashMap<Integer, String>();
    }

}

//public class UseSparseArrays implements exerciser{
//    @Override
//    public void exercise() {
//    SparseArray<String> array = new SparseArray<String>();
//    }
//}
